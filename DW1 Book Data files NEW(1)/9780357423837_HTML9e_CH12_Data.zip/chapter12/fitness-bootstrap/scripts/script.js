/*
    Student Name: Maria Cruz
    File Name: script.js
    Date: May 25, 2022
*/

//jQuery for hero image to consume the header window space