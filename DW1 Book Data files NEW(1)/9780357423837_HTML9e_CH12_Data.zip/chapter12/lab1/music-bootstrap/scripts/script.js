/*
    Student Name:
    File Name: script.js
    Date: 
*/

//jQuery for hero image to consume the header window space
$(document).ready(function(){
    $('.hero').height($(window).height());
});